import random
from odoo import api, models


class HrDashboard(models.Model):
    _name = 'hr.dashboard'

    @api.model
    def get_tiles_data(self,excluded_states=None):
        """Summary:
            when the page is loaded, get the data from different models and
            transfer to the js file.
            Return a dictionary variable.
        Return:
            type:It is a dictionary variable. This dictionary contains data that
             affects the dashboard view."""

        print('***get_tiles_data***')
        if excluded_states is None:
            excluded_states = []


        hr_leaves_tasks = self.env['hr.leaves'].search([('state', 'not in', excluded_states)])
        hr_work_resumption = self.env['hr.work.resumption'].search([('state', 'not in', excluded_states)])
        hr_status_change = self.env['status.change'].search([('state', 'not in', excluded_states)])
        hr_business_travel = self.env['business.travel'].search([('state', 'not in', excluded_states)])
        hr_advanced_housing = self.env['adv.housing'].search([('state', 'not in', excluded_states)])
        hr_loans = self.env['bank.loan'].search([('state', 'not in', excluded_states)])
        hr_nea = self.env['hr.employee.dept.manager'].search([('state', 'not in', excluded_states)])
        return {
            'hr_leaves_tasks': len(hr_leaves_tasks),
            'hr_leaves_tasks_ids': hr_leaves_tasks.ids,
            'hr_work_resumption': len(hr_work_resumption),
            'hr_work_resumption_ids': hr_work_resumption.ids,
            'hr_status_change': len(hr_status_change),
            'hr_status_change_ids': hr_status_change.ids,
            'hr_business_travel': len(hr_business_travel),
            'hr_business_travel_ids': hr_business_travel.ids,
            'hr_advanced_housing': len(hr_advanced_housing),
            'hr_advanced_housing_ids': hr_advanced_housing.ids,
            'hr_loans': len(hr_loans),
            'hr_loans_ids': hr_loans.ids,
            'hr_nea': len(hr_nea),
            'hr_nea_ids': hr_nea.ids,

        }

