
{
    'name': 'Hr Dashboard',
    'category': 'Hr',
    'summary': """Hr Dashboard For Odoo16 Community""",
    'description': """In this dashboard user the Detailed information about 
     HR.""",
    'version': '16.0',
    'author': 'Globalteckz',
    'company': 'Globalteckz',
    'maintainer': 'Globalteckz',
    'website': 'https://www.globalteckz.com',
    'license': 'LGPL-3',
    'depends': [
        'base','zamil_hr',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/dashboard_action.xml',
    ],
    # 'images': [
    #     'static/description/banner.png',
    # ],
    'assets': {
        'web.assets_backend': [
            'hr_dashboard/static/src/css/dashboard.css',
            "hr_dashboard/static/src/js/dashboard.js",
            'hr_dashboard/static/src/xml/dashboard.xml',
            # 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js'
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
