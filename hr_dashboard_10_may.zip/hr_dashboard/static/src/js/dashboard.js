odoo.define('hr_dashboard.Dashboard', function(require) {
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var QWeb = core.qweb;
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');
    var _t = core._t;
    var web_client = require('web.web_client');



        function loadChartJS(callback) {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
        script.onload = callback;
        document.head.appendChild(script);
    }



    var Dashboard1 = AbstractAction.extend({
        template: 'Dashboard1',

        events: {
            'click .tot_leaves': 'tot_leaves',
            'click .work_resumption': 'work_resumption',
            'click .status_change': 'status_change',
            'click .business_travel': 'business_travel',
            'click .advanced_housing': 'advanced_housing',
            'click .loans_approve': 'loans_approve',
            'click .nea_approve': 'nea_approve',
        },


        init: function(parent, context) {
            this._super(parent, context);
            this.dashboards_templates = ['Dashboard2'];
        },


        willStart: function() {
            var self = this;
            return $.when(this._super()).then(function() {
                return self.fetch_data();
            });
        },


        start: function() {
            var self = this;
            this.hr_leaves_tasks_ids = []; // Initialize hr_leaves_tasks_ids
            this.set("title", 'Dashboard');
            return this.fetch_data().then(function() {
                self.filterDataLeave(['validate', 'cancel']);
                self.filterDataResumption(['validate', 'cancel']);
                self.filterDataStatus(['approved', 'done']);
                self.filterDataBusiness(['approved', 'done']);
                self.filterDataHousing(['approved', 'refuse']);
                self.filterDataLoans(['approved', 'refuse']);
                self.filterDataNea(['approved', 'confirm_man']);
                self.render_dashboards();
                self.fetchAndRenderCharts();
            });
        },



        /**
        rendering the dashboard
        */
        render_dashboards: function() {
            var self = this;
            _.each(this.dashboards_templates, function(template) {
                self.$('.o_hr_dashboard').append(QWeb.render(template, {
                    widget: self
                }));
            });
        },



filterDataLeave: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_leaves_tasks = result['hr_leaves_tasks'];
        self.hr_leaves_tasks_ids = result['hr_leaves_tasks_ids'];

        // Render the updated count
        $('#hr_leaves_tasks').text(self.hr_leaves_tasks);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



filterDataResumption: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_work_resumption = result['hr_work_resumption'];
        self.hr_work_resumption_ids = result['hr_work_resumption_ids'];

        // Render the updated count
        $('#hr_work_resumption').text(self.hr_work_resumption);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



filterDataStatus: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_status_change = result['hr_status_change'];
        self.hr_status_change_ids = result['hr_status_change_ids'];

        // Render the updated count
        $('#hr_status_change').text(self.hr_status_change);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



filterDataBusiness: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_business_travel = result['hr_business_travel'];
        self.hr_business_travel_ids = result['hr_business_travel_ids'];

        // Render the updated count
        $('#hr_business_travel').text(self.hr_business_travel);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



filterDataHousing: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_advanced_housing = result['hr_advanced_housing'];
        self.hr_advanced_housing_ids = result['hr_advanced_housing_ids'];

        // Render the updated count
        $('#hr_advanced_housing').text(self.hr_advanced_housing);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



filterDataLoans: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_loans = result['hr_loans'];
        self.hr_loans_ids = result['hr_loans_ids'];

        // Render the updated count
        $('#hr_loans').text(self.hr_loans);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



filterDataNea: function(excludedStates) {
    var self = this;

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [excludedStates], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_nea = result['hr_nea'];
        self.hr_nea_ids = result['hr_nea_ids'];

        // Render the updated count
        $('#hr_nea').text(self.hr_nea);

        // Optionally, you can trigger a refresh of other parts of your dashboard here

    }, function(error) {
        console.error("Error fetching data:", error);
    });
},




tot_leaves: function(e) {
    console.log('TETSTSTSTS');
    console.log("hr_leaves_tasks_ids+_+_+_+_+_+", this.hr_leaves_tasks_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };


    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['validate', 'cancel']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_leaves_tasks = result['hr_leaves_tasks'];
        self.hr_leaves_tasks_ids = result['hr_leaves_tasks_ids'];

        $('#hr_leaves_tasks').text(self.hr_leaves_tasks);




        // Open window with updated data
        self.do_action({
            name: _t("Leaves"),
            type: 'ir.actions.act_window',
            res_model: 'hr.leaves',
            domain: [
                ["id", "in", self.hr_leaves_tasks_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);

        console.log("test+_+_+_+_+_+_+_+");
    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



 work_resumption: function(e) {
    console.log('TETSTSTSTS');
    console.log("hr_work_resumption_ids+_+_+_+_+_+", this.hr_work_resumption_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };

    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['validate', 'cancel']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_work_resumption = result['hr_work_resumption'];
        self.hr_work_resumption_ids = result['hr_work_resumption_ids'];

        self.do_action({
            name: _t("resumption"),
            type: 'ir.actions.act_window',
            res_model: 'hr.work.resumption',
            domain: [
                ["id", "in", self.hr_work_resumption_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);
        console.log("test+_+_+_+_+_+_+_+");
    }, function(error) {
        console.error("Error fetching work resumption data:", error);
    });
},



status_change: function(e) {
    console.log('TETSTSTSTS');
    console.log("hr_status_change_ids+_+_+_+_+_+", this.hr_status_change_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };

    // Fetch data again with filtering
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['approved', 'done']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_status_change = result['hr_status_change'];
        self.hr_status_change_ids = result['hr_status_change_ids'];


        // Open window with updated data
        self.do_action({
            name: _t("status"),
            type: 'ir.actions.act_window',
            res_model: 'status.change',
            domain: [
                ["id", "in", self.hr_status_change_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);

        console.log("test+_+_+_+_+_+_+_+");
    }, function(error) {
        console.error("Error fetching data:", error);
    });
},



business_travel: function(e) {
    console.log('TETSTSTSTS');
    console.log("hr_business_travel_ids+_+_+_+_+_+", this.hr_business_travel_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };

    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['approved', 'done']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_business_travel = result['hr_business_travel'];
        self.hr_business_travel_ids = result['hr_business_travel_ids'];

        self.do_action({
            name: _t("business"),
            type: 'ir.actions.act_window',
            res_model: 'business.travel',
            domain: [
                ["id", "in", self.hr_business_travel_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);
        console.log("test+_+_+_+_+_+_+_+");
    }).guardedCatch(function(error) {
        console.error("Error fetching business travel data:", error);
    });
},




advanced_housing: function(e) {
    console.log('TETSTSTSTS')
    console.log("hr_advanced_housing_ids+_+_+_+_+_+", this.hr_advanced_housing_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['approved', 'refuse']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_advanced_housing = result['hr_advanced_housing'];
        self.hr_advanced_housing_ids = result['hr_advanced_housing_ids'];

        self.do_action({
            name: _t("housing"),
            type: 'ir.actions.act_window',
            res_model: 'adv.housing',
            domain: [
                ["id", "in", self.hr_advanced_housing_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);
        console.log("test+_+_+_+_+_+_+_+");

    }).guardedCatch(function(error) {
        console.error("Error fetching advanced housing data:", error);
    });
},



loans_approve: function(e) {
    console.log('TETSTSTSTS');
    console.log("hr_loans_ids+_+_+_+_+_+", this.hr_loans_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };

    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['approved', 'refuse']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_loans = result['hr_loans'];
        self.hr_loans_ids = result['hr_loans_ids'];

        self.do_action({
            name: _t("loan"),
            type: 'ir.actions.act_window',
            res_model: 'bank.loan',
            domain: [
                ["id", "in", self.hr_loans_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);
        console.log("test+_+_+_+_+_+_+_+");
    }).guardedCatch(function(error) {
        console.error("Error fetching loans data:", error);
    });
},




nea_approve: function(e) {
    console.log('TETSTSTSTS');
    console.log("hr_nea_ids+_+_+_+_+_+", this.hr_nea_ids);
    var self = this;
    e.stopPropagation();
    e.preventDefault();
    var options = {
        on_reverse_breadcrumb: this.on_reverse_breadcrumb,
    };

    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data',
        args: [['approved', 'confirm_man']], // Pass filtering criteria as arguments
    }).then(function(result) {
        // Update the data
        self.hr_nea = result['hr_nea'];
        self.hr_nea_ids = result['hr_nea_ids'];

        self.do_action({
            name: _t("nea"),
            type: 'ir.actions.act_window',
            res_model: 'hr.employee.dept.manager',
            domain: [
                ["id", "in", self.hr_nea_ids]
            ],
            view_mode: 'list,form',
            views: [
                [false, 'list'],
                [false, 'form']
            ],
            target: 'current'
        }, options);
        console.log("test+_+_+_+_+_+_+_+");
    }).guardedCatch(function(error) {
        console.error("Error fetching NEA approval data:", error);
    });
},




createDoughnutChart: function(canvasClass, data, labels, backgroundColor,width, height) {
    var self = this;
    loadChartJS(function() {
        var canvas = document.getElementsByClassName(canvasClass)[0];
        if (!canvas) {
            console.error("Canvas element with class '" + canvasClass + "' not found.");
            return;
        }
        var ctx = canvas.getContext('2d');
        if (!ctx) {
            console.error("Unable to retrieve 2D rendering context for canvas element.");
            return;
        }
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColor
                }]
            }

        });
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
    });
},


// Fetch data and render charts
fetchAndRenderCharts: function() {
    var self = this;
    this._rpc({
        model: 'hr.dashboard',
        method: 'get_tiles_data'
    }).then(function(result) {
        // Extract data from result
        var chartData = {
            tot_leaves: result['hr_leaves_tasks'],
            work_resumption: result['hr_work_resumption'],
            status_change: result['hr_status_change'],
            business_travel: result['hr_business_travel'],
            advanced_housing: result['hr_advanced_housing'],
            loans_approve: result['hr_loans'],
            nea_approve: result['hr_nea']
        };


        // Create doughnut charts with custom colors
        self.createDoughnutChart('tot_leaves_chart', chartData.tot_leaves, ['Leaves'], ['#ec7063']);
        self.createDoughnutChart('work_resumption_chart', chartData.work_resumption, ['Resumption'],['#1d8348']);
        self.createDoughnutChart('status_change_chart', chartData.status_change, ['Status Change'], ['#2e86c1']);
        self.createDoughnutChart('business_travel_chart', chartData.business_travel, ['Business Travel'], ['#667943']);
        self.createDoughnutChart('advanced_housing_chart', chartData.advanced_housing, ['ADV Housing'], ['#909497']);
        self.createDoughnutChart('loans_approve_chart', chartData.loans_approve, ['Loan Approval'], ['rgb(255, 86, 65)']);
        self.createDoughnutChart('nea_approve_chart', chartData.nea_approve, ['NEA Approval'], ['#C06C84']
        );
    });
},




//      function for getting values when page is loaded
        fetch_data: function() {
            this.flag = 0
            var self = this;
            var def1 = this._rpc({
                model: 'hr.dashboard',
                method: 'get_tiles_data'
            }).then(function(result) {
               self.hr_leaves_tasks = result['hr_leaves_tasks']
               self.hr_leaves_tasks_ids = result['hr_leaves_tasks_ids']
               self.hr_work_resumption = result['hr_work_resumption']
               self.hr_work_resumption_ids = result['hr_work_resumption_ids']
               self.hr_status_change = result['hr_status_change']
               self.hr_status_change_ids = result['hr_status_change_ids']
               self.hr_business_travel = result['hr_business_travel']
               self.hr_business_travel_ids = result['hr_business_travel_ids']
               self.hr_advanced_housing = result['hr_advanced_housing']
               self.hr_advanced_housing_ids = result['hr_advanced_housing_ids']
               self.hr_loans = result['hr_loans']
               self.hr_loans_ids = result['hr_loans_ids']
               self.hr_nea = result['hr_nea']
               self.hr_nea_ids = result['hr_nea_ids']
            });
            console.log("fectch_data_+++++++++++++")
            return $.when(def1);
        },
    });
    core.action_registry.add('custom_hr_dashboard_tag', Dashboard1);
    return Dashboard1;
});