# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class gt_two_factor_authentication(models.Model):
#     _name = 'gt_two_factor_authentication.gt_two_factor_authentication'
#     _description = 'gt_two_factor_authentication.gt_two_factor_authentication'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

