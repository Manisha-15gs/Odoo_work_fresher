from odoo import api, fields, models, _
from odoo.exceptions import UserError


class ResCompany(models.Model):
    _inherit = "res.company"
    # whenever we inherit any module we need to use _inherit

    email_id = fields.Char(string="Email (App Key)")
    app_key = fields.Char(string="App key")
