# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request, route
import random
from odoo.http import request
from odoo import http
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import smtplib
import base64
import secrets
from odoo.addons.portal.controllers import portal
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from smtplib import SMTPAuthenticationError


class GtTwoFactorAuthentication(http.Controller):
    @http.route('/otp', auth='public', website=True)
    def index(self, **kw):
        print(kw, "**********************88")
        login = kw.get('login')
        otp = ''.join(random.choices('0123456789', k=4))
        print(otp, "**********************88")
        print(otp, "**********************88")
        print(otp, "**********************88")
        print(request.env.company, "**********************88")
        print(request.env.company.email_id, "**********************88")
        print(request.env.company.app_key, "**********************88")
        try:
            body = f"This OTP is valid for a single use and will expire shortly. Please enter this OTP when prompted during the login process to complete the verification.\n{otp}"
            to_email = str(login)
            from_email = request.env.company.email_id  # Sender's email
            password = request.env.company.app_key  # Sender's email password
            smtp_server = 'smtp.gmail.com'
            smtp_port = 587
            msg = MIMEMultipart()
            msg['From'] = from_email
            msg['To'] = to_email
            msg['Subject'] = "Your OTP for Two-Step Verification"
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(from_email, password)
            server.sendmail(from_email, to_email, msg.as_string())

            server.quit()
        except SMTPAuthenticationError:
            raise UserError(_("Invalid credentials of Admin: Please check your email and app key configuration and try again."))

        values = {
            "login": login,
            "otp": otp,
        }

        return request.render("gt_two_factor_authentication.web_otp_id", values)

#     @http.route('/gt_two_factor_authentication/gt_two_factor_authentication/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('gt_two_factor_authentication.listing', {
#             'root': '/gt_two_factor_authentication/gt_two_factor_authentication',
#             'objects': http.request.env['gt_two_factor_authentication.gt_two_factor_authentication'].search([]),
#         })

#     @http.route('/gt_two_factor_authentication/gt_two_factor_authentication/objects/<model("gt_two_factor_authentication.gt_two_factor_authentication"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gt_two_factor_authentication.object', {
#             'object': obj
#         })
