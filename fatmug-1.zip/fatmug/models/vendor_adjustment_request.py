


class VendorAdjustmentRequest(models.Model):
    _name = 'vendor.adjustment.request'
    _description = 'Vendor Adjustment Request'

    order_id = fields.Many2one('sale.order', string='Order', required=True)
    adjustment_detail = fields.Text(string='Adjustment Detail', required=True)
    comment = fields.Text(string='Comment')

    @api.model
    def create(self, vals):
        adjustment_request = super(VendorAdjustmentRequest, self).create(vals)

        # Trigger email notification upon request submission
        subject = "New Adjustment Request Submitted"
        body = f"Adjustment request submitted for order {adjustment_request.order_id.name}."
        notification_vals = {
            'subject': subject,
            'body_html': body,
            'email_to': self.env.user.partner_id.email,
            'model': 'vendor.adjustment.request',
            'res_id': adjustment_request.id,
        }
        self.env['mail.mail'].create(notification_vals).send()

        return adjustment_request